import numpy as np
import streamlit as st
import tensorflow as tf
from PIL import Image

MODEL_PATH = "model/pneumonia_model.keras"
LABELS = ["Normal", "Pneumonia"]

st.set_page_config(page_title="Pneumonia Detector", page_icon="🫁", layout="centered")


@st.cache_resource
def load_model():
    return tf.keras.models.load_model(MODEL_PATH)


def preprocess(img: Image.Image) -> np.ndarray:
    """Same preprocessing as training: grayscale, 28x28, scaled to 0-1."""
    img = img.convert("L").resize((28, 28), Image.LANCZOS)
    arr = np.asarray(img, dtype=np.float32) / 255.0
    return arr.reshape(1, 28, 28, 1)


st.title("🫁 Pneumonia Detector")
st.caption("A small CNN trained on PneumoniaMNIST (28×28 chest X-rays).")

st.warning(
    "Educational demo only. This is **not** a medical device and must not be "
    "used for diagnosis. Consult a qualified doctor."
)

with st.sidebar:
    st.header("Settings")
    threshold = st.slider("Decision threshold", 0.05, 0.95, 0.50, 0.05,
                          help="Lower = catches more pneumonia cases but more false alarms.")
    st.markdown("**Model:** 2× Conv + Dense CNN, ~56K parameters")
    st.markdown("**Test accuracy:** ~83% (PneumoniaMNIST test split)")

uploaded = st.file_uploader("Upload a chest X-ray (PNG/JPG)", type=["png", "jpg", "jpeg"])

if uploaded:
    image = Image.open(uploaded)
    col1, col2 = st.columns(2)
    col1.image(image, caption="Uploaded image", use_container_width=True)
    col2.image(image.convert("L").resize((28, 28), Image.LANCZOS),
               caption="What the model sees (28×28)", width=200)

    if st.button("Analyze", type="primary"):
        model = load_model()
        prob = float(model.predict(preprocess(image), verbose=0)[0][0])
        label = LABELS[int(prob >= threshold)]

        if label == "Pneumonia":
            st.error(f"Prediction: **{label}**")
        else:
            st.success(f"Prediction: **{label}**")
        st.metric("Pneumonia probability", f"{prob:.1%}")
        st.progress(prob)
else:
    st.info("Upload an X-ray image to begin.")
